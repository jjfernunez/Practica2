package java02;

import java.awt.*;
import java.awt.event.*;
import java.text.NumberFormat;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.text.*;

import java.text.*;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;



public class Banco extends JFrame
{
   
    //Etiquetas para identificar los campos de texto
    private JLabel numeroLabel;
    private JLabel propietarioLabel;
    private JLabel fechaLabel;
    private JLabel saldoLabel;

    //Cadenas para las etiquetas
    private static String numeroString = "Número de cuenta: ";
    private static String propietarioString = "Propietario de cuenta: ";
    private static String fechaString = "Fecha de creacion: ";
    private static String saldoString = "Saldo: ";

    //Text fields para introducir números
    private TextField numeroField;
    private TextField propietarioField;
    private TextField fechaField;
    private TextField saldoField;
    private TextField emptyField;
    
    private boolean focusIsSet = false;

    public Banco() {
        super("Banco");

        
        
        
        
        
        
        //Crea las etiquetas.
        numeroLabel = new JLabel(numeroString);
        propietarioLabel = new JLabel(propietarioString);
        fechaLabel = new JLabel(fechaString);
        saldoLabel = new JLabel(saldoString);

        //Campo donde voy a poner los datos de las cuentas
        numeroField = new TextField(10);
        numeroField.setText(""+Cuenta.getInicio().getNumero());
        numeroField.setEditable(false);
        
        propietarioField = new TextField(10);
        propietarioField.setText(""+Cuenta.getInicio().getPropietario());
        propietarioField.setEditable(false);
        
        fechaField = new TextField(10);
        fechaField.setText(""+ Cuenta.getInicio().getFecha().get(Calendar.DATE)+"/"+Cuenta.getInicio().getFecha().get(Calendar.MONTH)+"/"+Cuenta.getInicio().getFecha().get(Calendar.YEAR));
        fechaField.setEditable(false);
        
        saldoField = new TextField(10);
        saldoField.setText(""+Cuenta.getInicio().getSaldo());
        saldoField.setEditable(false);
        
        
       emptyField = new TextField(10);
       emptyField.setVisible(false);
       emptyField.setEditable(false);
        emptyField.setBounds(30,30,30,30);
       
        
        //Creo botones
       JButton botonAnterior = new JButton("Anterior");
       
     
       JButton botonSiguiente = new JButton("Siguiente");
       
       
        JButton botonCrear = new JButton("NuevaCuenta");
        
        JButton botonAceptar = new JButton("Aceptar");
        JButton botonCancelar = new JButton("Cancelar");
        
        botonAceptar.setVisible(false);
        botonCancelar.setVisible(false);
       
        //Dispone la geometría de las etiquetas en un panel
        JPanel labelPanel = new JPanel();
        labelPanel.setLayout(new GridLayout(0, 1));
        labelPanel.add(numeroLabel);
        labelPanel.add(propietarioLabel);
        labelPanel.add(fechaLabel);
        labelPanel.add(saldoLabel);
        labelPanel.add(botonCancelar);
        
        //Panel para el boton central
        JPanel middlePanel = new JPanel();
        middlePanel.setLayout(new GridLayout(1, 0));
       
        middlePanel.add(botonAnterior);
        middlePanel.add(botonCrear);
        middlePanel.add(botonSiguiente);
        
        
        
        //Dispone los campos de texto en otro panel
        JPanel fieldPanel = new JPanel();
        fieldPanel.setLayout(new GridLayout(0, 1));
        fieldPanel.add(numeroField);
        fieldPanel.add(propietarioField);
        fieldPanel.add(fechaField);
        fieldPanel.add(saldoField);
        fieldPanel.add(botonAceptar);

        //Incluye los dos paneles en otro panel,
        //etiquetas a la izquierda
        //y campos de texto a la derecha.
        JPanel contentPane = new JPanel();
        contentPane.setBorder(
        BorderFactory.createEmptyBorder(20, 20, 20, 20));
        contentPane.setLayout(new BorderLayout());
        contentPane.add(labelPanel, BorderLayout.WEST);
        contentPane.add(middlePanel, BorderLayout.SOUTH);
        contentPane.add(fieldPanel, BorderLayout.CENTER);
        
        setContentPane(contentPane); 

          
        botonAnterior.addActionListener(new ActionListener() {  
            public void actionPerformed(ActionEvent e) {
                
                 Cuenta cu = Cuenta.getActual();
                if(cu.getAnterior() != null){
                    Cuenta.setActual(cu.getAnterior());
                    cu = Cuenta.getActual();    
                    refresco(cu); 
                    botonSiguiente.setEnabled(true);
                    if(cu.getAnterior() == null){
                         botonAnterior.setEnabled(false);
                    }
                }
                
            }
        });
       
          
        botonSiguiente.addActionListener(new ActionListener() {  
            public void actionPerformed(ActionEvent e) {
                Cuenta cu = Cuenta.getActual();
                if(cu.getSiguiente() != null){                 
                    Cuenta.setActual(cu.getSiguiente());
                    cu = Cuenta.getActual();
                    refresco(cu);
                botonAnterior.setEnabled(true);
                    if(cu.getSiguiente() == null){
                         botonSiguiente.setEnabled(false);
                    }
                }
                

            }
        });
        
        
        botonCrear.addActionListener(new ActionListener() {  
            public void actionPerformed(ActionEvent e) {
                
                
                
                GregorianCalendar fecha = new GregorianCalendar(new Locale("es", "ES"));
                numeroField.setText("Autonumerico");
                numeroField.setBackground(Color.gray);
               propietarioField.setText("");
               fechaField.setText(""+(fecha.get(Calendar.DATE)+"/"+fecha.get(Calendar.MONTH))+"/"+fecha.get(Calendar.YEAR));
               fechaField.setBackground(Color.GRAY);
               saldoField.setText("");
                
               
               propietarioField.setEditable(true);
               saldoField.setEditable(true);
              
              
               
                botonCrear.setVisible(false);
                botonSiguiente.setVisible(false);
                botonAnterior.setVisible(false);
                botonAceptar.setVisible(true);
                botonCancelar.setVisible(true);
                
              
               
               
               botonAceptar.addActionListener(new ActionListener() {  
                    public void actionPerformed(ActionEvent e) {
                        
                       String propietario = propietarioField.getText();
                        float saldo = Float.parseFloat(saldoField.getText());
                        Cuenta nuevaCuenta = new Cuenta(saldo, propietario, fecha.get(Calendar.DATE), fecha.get(Calendar.MONTH), fecha.get(Calendar.YEAR));       
                        
                        
                        propietarioField.setEditable(false);
                        saldoField.setEditable(false);
                        
                        numeroField.setBackground(null);
                        fechaField.setBackground(null);
                        
                        
                        botonSiguiente.setVisible(true);
                        botonAnterior.setVisible(true);
                        botonAceptar.setVisible(false);
                        botonCancelar.setVisible(false);
                         botonCrear.setVisible(true);
                        Cuenta cu = Cuenta.getActual();
                        refresco(cu);
                }             
                    
                
            });
               botonCancelar.addActionListener(new ActionListener() {  
                    public void actionPerformed(ActionEvent e) {
                        
                        numeroField.setBackground(null);
                        fechaField.setBackground(null);
                        
                       botonSiguiente.setVisible(true);
                botonAnterior.setVisible(true);
                botonAceptar.setVisible(false);
                botonCancelar.setVisible(false);  
                 botonCrear.setVisible(true);
                Cuenta cu = Cuenta.getActual();
                refresco(cu);
                }             
                
            });

            }
        });
       
    }
    
    

    public static void main(String[] args) {
        
       
        
        
       Cuenta.crearCuenta();
        
        final Banco app = new Banco();

      
        //Lo que pasa si cerramos la ventana
        app.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }

            //Pone el focus (foco de atencion)
            public void windowActivated(WindowEvent e) {
                app.setFocus();
            }
        });
        app.pack();
        app.setVisible(true);
    }

    private void setFocus() {
        if (!focusIsSet) {
            numeroField.requestFocus();
            focusIsSet = true;
        }
    }
    
    
    public void refresco(Cuenta cu){
        
      
        numeroField.setText(""+cu.getNumero());
        propietarioField.setText(""+cu.getPropietario());
        fechaField.setText(""+ cu.getFecha().get(Calendar.DATE)+"/"+cu.getFecha().get(Calendar.MONTH)+"/"+cu.getFecha().get(Calendar.YEAR));
        saldoField.setText(""+cu.getSaldo());
        
        
    }

}
