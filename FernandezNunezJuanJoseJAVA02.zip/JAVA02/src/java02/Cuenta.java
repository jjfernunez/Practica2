/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package java02;

import java.util.*;
/**
 *
 * @author alumno
 */
public class Cuenta {
    
   
    private int numero;
    private GregorianCalendar fecha; 
    private float saldo;
    private String propietario;
    
    private Cuenta siguiente = null;
    private Cuenta anterior = null;
    
    private static int numeroEstatico = 1;
    
    private static Cuenta inicio = null;
    private static Cuenta actual = null;
    
    
    public Cuenta()
    {
    
    }

    public Cuenta(float saldo, String propietario, int dia, int mes, int anio){
        
        setFecha(anio,mes,dia);
        setNumero(numeroEstatico);
        numeroEstatico++;
        setSaldo(saldo);
        setPropietario(propietario);
        
        
        if(inicio == null){
            inicio = this;
            this.siguiente = null;
            this.anterior = null;
    
        }
        else{
            inicio.anterior = this;
            this.anterior = null;
            siguiente = inicio;
            inicio = this;
            
            
        }
        
    }
    
 
    /**
     * @return the numero
     */
    public int getNumero() {
        return numero;
    }

    /**
     * @param numero the numero to set
     */
    public void setNumero(int numero) {
        this.numero = numero;
    }

    /**
     * @return the fecha
     */
    public GregorianCalendar getFecha() {
        return fecha;
    }

    /**
     * @param anio
     * @param fecha the fecha to set
     */
    public void setFecha(int anio, int mes, int dia) {
        this.fecha = new GregorianCalendar(anio, mes, dia);
    }

    /**
     * @return the saldo
     */
    public float getSaldo() {
        return saldo;
    }

    /**
     * @param saldo the saldo to set
     */
    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }

    /**
     * @return the propietario
     */
    public String getPropietario() {
        return propietario;
    }

    /**
     * @param propietario the propietario to set
     */
    public void setPropietario(String propietario) {
        this.propietario = propietario;
    }

    /**
     * @return the inicio
     */
    public static Cuenta getInicio() {
        return inicio;
    }

    /**
     * @param aInicio the inicio to set
     */
    public static void setInicio(Cuenta aInicio) {
        inicio = aInicio;
    }

    /**
     * @return the actual
     */
    public static Cuenta getActual() {
        return actual;
    }

    /**
     * @param aActual the actual to set
     */
    public static void setActual(Cuenta aActual) {
        actual = aActual;
    }

    /**
     * @return the siguiente
     */
    public Cuenta getSiguiente() {
        return siguiente;
    }

    /**
     * @param aSiguiente the siguiente to set
     */
    public void setSiguiente(Cuenta aSiguiente) {
        siguiente = aSiguiente;
    }
    
     public Cuenta getAnterior() {
        return anterior;
    }

    /**
     * @param anterior
     */
    public void setAnterior(Cuenta anterior) {
        this.anterior = anterior;
    }
    
    /**
     *
     * @return 
     */
    @Override
    public String toString(){
        String imprime = ("Numero de cuenta: "+ this.getNumero());
        imprime += ("\nPropietario: "+ this.getPropietario());
        imprime +=("\nSaldo: "+ this.getSaldo());
        imprime +=("\nFecha de creacion: "+ this.getFecha().get(Calendar.DATE)+"/"+this.getFecha().get(Calendar.MONTH)+"/"+this.getFecha().get(Calendar.YEAR));

        return imprime;
    }
    
    public static void crearCuenta(){
        Cuenta cuenta1 = new Cuenta(1800, "Juan Jose", 21, 9, 2022);
        Cuenta cuenta2 = new Cuenta(29000, "Jose Manuel", 12, 3, 2020);
        Cuenta cuenta3 = new Cuenta(15000, "Alberto", 4, 7, 2021);
        Cuenta cuenta4 = new Cuenta(3000, "Paula", 15, 2, 2021);
        Cuenta cuenta5 = new Cuenta(45678, "Alvaro", 12, 3, 2020);
        
        Cuenta.setActual(Cuenta.getInicio());
    }
    
    public void avanzar(){
        Cuenta.setActual(Cuenta.getActual().getSiguiente());
        
    }
    public void anterior(){
        Cuenta.setActual(Cuenta.getActual().getAnterior());
        
    }
    
}
